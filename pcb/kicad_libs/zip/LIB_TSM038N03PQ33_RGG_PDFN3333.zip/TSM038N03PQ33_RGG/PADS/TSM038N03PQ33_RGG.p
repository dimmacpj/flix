*PADS-LIBRARY-PART-TYPES-V9*

TSM038N03PQ33_RGG TSM038N03PQ33RGG I TRX 9 1 0 0 0
TIMESTAMP 2026.10.29.12.15.27
"Manufacturer_Name" Taiwan Semiconductor
"Manufacturer_Part_Number" TSM038N03PQ33 RGG
"Mouser Part Number" 821-TSM038N03PQ33RGG
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Taiwan-Semiconductor/TSM038N03PQ33-RGG?qs=QEzMiVqgwc0dH14meb3EeQ%3D%3D
"Arrow Part Number" TSM038N03PQ33 RGG
"Arrow Price/Stock" https://www.arrow.com/en/products/tsm038n03pq33rgg/taiwan-semiconductor
"Description" MOSFET Power MOSFET, N-CHAN 30V, 80A, 3.8mOhm
"Datasheet Link" https://www.mouser.com/datasheet/2/395/TSM038N03PQ33_B1610-1143140.pdf
"Geometry.Height" 0.8mm
GATE 1 9 0
TSM038N03PQ33_RGG
1 0 U S_1
2 0 U S_2
3 0 U S_3
4 0 U G
5 0 U D_1
6 0 U D_2
7 0 U D_3
8 0 U D_4
9 0 U D_5

*END*
*REMARK* SamacSys ECAD Model
1543899/1894454/2.50/9/4/MOSFET (N-Channel)
