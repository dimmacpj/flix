*PADS-LIBRARY-PART-TYPES-V9*

MCGL2D1N03YL-TP MCG09P06HE3TP I TRX 9 1 0 0 0
TIMESTAMP 2026.10.29.12.14.27
"Manufacturer_Name" MCC
"Manufacturer_Part_Number" MCGL2D1N03YL-TP
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" N-Channel MOSFET
"Datasheet Link" https://www.mccsemi.com/pdf/Products/MCGL2D1N03YL(PDFN3333-B).pdf
"Geometry.Height" 0.85mm
GATE 1 9 0
MCGL2D1N03YL-TP
1 0 U S_1
2 0 U S_2
3 0 U S_3
4 0 U G
5 0 U D_1
6 0 U D_2
7 0 U D_3
8 0 U D_4
9 0 U D_5

*END*
*REMARK* SamacSys ECAD Model
19643959/1894454/2.50/9/2/MOSFET (N-Channel)
